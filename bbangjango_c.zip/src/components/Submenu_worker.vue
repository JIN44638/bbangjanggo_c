<template>
기사페이지 서브메뉴

</template>
<script setup></script>
<style scoped></style>