<template>기사 마이페이지</template>
<script setup></script>
<style scoped></style>